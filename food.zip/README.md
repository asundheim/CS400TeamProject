# CS400TeamProject
 - Anders Sundheim, asundheim@wisc.edu
 - Jakob Paquette, jpaquette@wisc.edu
 - Jacob Meyer, jmeyer32@wisc.edu
 - Alex Rusnak, atrusnak@wisc.edu
 
[![Build Status](https://travis-ci.org/DarthEvandar/CS400TeamProject.svg?branch=master)](https://travis-ci.org/DarthEvandar/CS400TeamProject)
